from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns = [
    path('', views.project_list, name='project_list'),
    path('/home',views.index,name='index'),
    path('monthly/',views.monthly,name='monthly'),
    path('login/',views.login,name='monthly'),
    path('welcome/',views.welcome,name='monthly'),
    path('generate/',views.generate,name='monthly'),
    path('mastersheet/<int:project_id>/',views.mastersheet,name='mastersheet'),
    path('save_table_data_to_file/', views.save_table_data_to_file, name='save_table_data_to_file'),
    # path('save_tables_to_file/', views.save_tables_to_file, name='save_tables_to_file'),
    path('save_data/', views.save_data_to_file, name='save_data_to_file'),
    # path('save_table_data/', views.save_table_data, name='save_table_data'),
    path('save_tables_to_file/<int:project_id>/', views.save_tables_to_file, name='save_tables_to_file'),
    path('save_table_data/<int:project_id>/', views.save_table_data, name='save_table_data'),
    path('fill/<int:project_id>/', views.fill, name='fill'),
]