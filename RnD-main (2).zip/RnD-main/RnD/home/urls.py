from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns = [
    path('index/',views.index,name='index'),
    path('',views.homepage,name='homepage'),
    path('monthly/',views.monthly,name='monthly'),
    path('login/',views.login,name='login'),
    path('project_list/',views.project_list,name='project_list'),
    path('fill/<int:project_id>/',views.fill,name='fill'),
    path('mastersheet/<int:project_id>/',views.mastersheet,name='mastersheet'),
    path('save_table_data/<int:project_id>/',views.save_table_data,name='save_table_data'),
    path('save_tables_to_file/<project_id>/', views.save_tables_to_file, name='save_tables_to_file'),
    path('save_data_to_file/', views.save_data_to_file, name='save_data_to_file'),
    path('logout/',views.logout,name='logout'),
    path('save_table_data1/<int:project_id>/', views.save_table_data1, name='save_table_data1'),
    path('completed_list', views.completed_list, name='completed_list'),
    path('project_search/', views.project_search, name='project_search'),
    path('project_search_completed/', views.project_search_completed, name='project_search_completed'),
    path('complete_task/<int:project_id>/', views.complete_task, name='complete_task'),
    path('ucr/',views.ucr,name='ucr'),
    path('soe/' ,views.soe, name='soe'),

    # path('soe/<int:project_id>/', views.soe, name='soe'),
]