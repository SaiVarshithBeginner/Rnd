from django.contrib import admin
from .models import table_info,project_details,project_details1,Comment
# Register your models here.
admin.site.register(table_info)
admin.site.register(project_details)
admin.site.register(project_details1)
admin.site.register(Comment)
